<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RoleSeeder::class,
            PermissionSeeder::class,
            UserSeeder::class,
            DepartmentSeeder::class,
            BuildingSeeder::class,
            RoomSeeder::class,
            SubjectSeeder::class,
            EvaluationSeeder::class,
            PhaseSeeder::class,
            QuestionSeeder::class,
            SectionSeeder::class,
            // QuestionResponseSeeder::class,
        ]);
    }
}
