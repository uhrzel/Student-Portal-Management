<x-admin-layout>
    <livewire:teacher.room :subjectId="$subject_id" />
</x-admin-layout>