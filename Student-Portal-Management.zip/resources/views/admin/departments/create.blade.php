<x-admin-layout>
    <livewire:admin.department.create />
</x-admin-layout>