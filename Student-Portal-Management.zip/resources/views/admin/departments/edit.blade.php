<x-admin-layout>
    <livewire:admin.department.edit :department_id="$department_id" />
</x-admin-layout>