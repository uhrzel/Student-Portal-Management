<x-admin-layout>
    <livewire:admin.department.index />
</x-admin-layout>