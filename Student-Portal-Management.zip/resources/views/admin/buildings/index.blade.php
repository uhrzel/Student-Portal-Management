<x-admin-layout>
    <livewire:admin.building.index />
</x-admin-layout>