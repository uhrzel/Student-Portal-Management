<x-admin-layout>
    <livewire:admin.building.edit :building_id="$building_id" />
</x-admin-layout>