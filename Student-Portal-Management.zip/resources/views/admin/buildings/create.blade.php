<x-admin-layout>
    <livewire:admin.building.create />
</x-admin-layout>