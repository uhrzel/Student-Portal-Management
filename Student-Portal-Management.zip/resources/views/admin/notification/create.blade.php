<x-admin-layout>
    <livewire:notification.create />
</x-admin-layout>