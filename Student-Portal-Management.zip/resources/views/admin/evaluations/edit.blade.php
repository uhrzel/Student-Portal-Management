<x-admin-layout>
    <livewire:admin.evaluations.edit :evaluation_id="$evaluation_id" />
</x-admin-layout>