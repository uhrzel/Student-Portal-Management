<x-admin-layout>
    <livewire:admin.roles.edit :role_id="$role_id" />
</x-admin-layout>