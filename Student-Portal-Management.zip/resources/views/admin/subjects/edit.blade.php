<x-admin-layout>
    <livewire:admin.subjects.edit :subject_id="$subject_id" />
</x-admin-layout>