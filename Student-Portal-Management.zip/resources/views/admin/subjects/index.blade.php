<x-admin-layout>
    <livewire:admin.subjects.index />
</x-admin-layout>