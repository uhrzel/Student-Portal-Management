<x-admin-layout>
    <livewire:admin.subjects.create />
</x-admin-layout>