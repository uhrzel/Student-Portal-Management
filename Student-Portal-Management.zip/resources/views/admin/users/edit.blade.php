<x-admin-layout>
    <livewire:admin.users.edit :user_id="$user_id" />
</x-admin-layout>