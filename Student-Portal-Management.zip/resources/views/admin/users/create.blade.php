<x-admin-layout>
    <livewire:admin.users.create />
</x-admin-layout>