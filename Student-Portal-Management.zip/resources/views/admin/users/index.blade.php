<x-admin-layout>
    <livewire:admin.users.index />
</x-admin-layout>