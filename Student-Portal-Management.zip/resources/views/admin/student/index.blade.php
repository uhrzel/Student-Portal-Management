<x-admin-layout>
    <livewire:admin.student.index />
</x-admin-layout>