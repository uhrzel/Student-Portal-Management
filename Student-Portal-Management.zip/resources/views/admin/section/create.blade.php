<x-admin-layout>
    <livewire:admin.section.create />
</x-admin-layout>
