<x-admin-layout>
    <livewire:admin.section.student />
</x-admin-layout>