<x-admin-layout>
    <livewire:admin.section.index />
</x-admin-layout>