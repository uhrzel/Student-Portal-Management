<x-admin-layout>
    <livewire:admin.section.edit :section_id="$section_id" />
</x-admin-layout>