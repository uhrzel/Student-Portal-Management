<x-admin-layout>
    <livewire:admin.rooms.index />
</x-admin-layout>