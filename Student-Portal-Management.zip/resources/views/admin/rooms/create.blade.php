<x-admin-layout>
    <livewire:admin.rooms.create />
</x-admin-layout>