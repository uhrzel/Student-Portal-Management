<x-admin-layout>
    <livewire:admin.rooms.edit :room_id="$room_id" />
</x-admin-layout>