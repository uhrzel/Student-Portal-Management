<div>
    @livewire('layout.navigation-menu')
</div>