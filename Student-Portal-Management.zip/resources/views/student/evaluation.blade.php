<x-app-layout>
    <livewire:student.evaluation :roomSection="$roomSection" />
</x-app-layout>