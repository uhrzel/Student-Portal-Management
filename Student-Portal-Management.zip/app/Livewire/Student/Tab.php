<?php

namespace App\Livewire\Student;

use Livewire\Component;

class Tab extends Component
{

    public function render()
    {
        return view('livewire.student.tab');
    }
}
